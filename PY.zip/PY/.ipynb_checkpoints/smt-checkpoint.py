# #capitalize() 1
# txt = input("Enter a string: ")
# if txt[0] in txt : 
#     # Capitalize the first character
#     txt = txt.capitalize()

# print(txt)

# #2
# txt1 = input("enter a string:")
# num = int(input("enter num:"))
# holder = txt1
# count = 0
# while count < num:
#     print(txt1.capitalize())
#     count +=1



# casefold()
# txt = input("enter smt:")

# if txt.capitalize() in txt:
#     cap=  txt.casefold()
#     print(cap)

# else : 
#     print(txt)
# tu index 0 aris upper mashin yvelas casefold() es uppercase mtlianad sheidzleba
# txt = input("enter smt:")
# for i in range(len(txt)):
#     if txt[0].capitalize() in txt :
#         print (txt[i].casefold())



# center()

# txt = input("enter text:")
# num = int(input("enter num to center:"))
# pad = input("enter:")
# holder = txt.center(num,pad)
# print(holder)

# txt = input("enter smt:")
# num = int(input("enter Num:"))
# x = txt.center(len(txt)+num,"S")
# print(x)     

# txt = input("enter text:")
# finder = input("enter word to search for:")
# field = int(input("enter are to search from :"))
# field1 = int(input("to:"))
# smt = input("enter simbol to pad")

# if field < 0 or field1 > len(txt) or field > field1:
#     print("Out of range")
# else:    
#  cutter = txt[field:field1]
# if finder in cutter:
#     print("found in range")
# else :
#    print("not found in the range")

# centerTxt  = cutter.center(len(cutter) +10,smt)
# print(centerTxt)

# count()

# txt = input("enter text:")
# x = input("enter Word to search for:")
# print(txt.count(x))
# import random
# txt =input("enter smt")
# char = input("enter char to search for : ")
# x = txt.count(char)
# print(x)
# z = random.randint(0,10)
# print(z)
# while x < z :
#     print("Paata mas")
#     x+=1

# encode() gaaugebaria

# txt = "salami"
# print(txt.encode())

# endswith()

# txt = input("enter text:")
# if txt.endswith(".") != True:
#     print(txt,end=".")
# else:
#     print(txt)    


# txt =input("enter text:")
# checker = input("Type what text should end with:")
# range1 = int(input("enter from where to start search:"))
# range2 = int(input("Where to finish:"))

# cutter = txt[range1:range2] #vchri sityvas

# if cutter.endswith(checker):
#     print(True)
# else:
#     print(False)    


# expandtabs() c samushao maq

# txt = input("Enter text with tabs: ")
# expanded_txt = txt.expandtabs()  
# print("Expanded text:")
# print(expanded_txt)

# find()

# txt = input("enter text:")
# checker  = input("enter word or char to find :")
# range1= int(input("start:"))
# range2 = int(input("end"))

# cut =txt[range1:range2]

# if cut.find(checker) :
#     print("i have succesfuly founded ")
# else:
#     print("out of range or wrong word/char")

# txt = input("Enter text:")
# checker = input("enter enter char or word to search for:")
# finder = txt.find(checker)

# if finder != -1 :
#     print(finder)   
# else:
#     print("couldnt find")    


# format()

# fullname = input("enter your full name:")
# age = int(input("enter your age"))
# fullname = fullname.capitalize()
# greeting = "hello {fullname},you are {age} years old".format(fullname=fullname,age=age)
# print(greeting)

# smt = int(input("enter num and i will auto convert it into binary number"))
# out ="binary version of {smt} is {smt:b}"
# print(out.format(smt=smt))

#         format_map ar irtveba tumca principi movidzie

# index()

# txt = input("enter a string:")
# checker = input("enter a char to find")
# finder = txt.index(checker)
# print("Your checker is foound at index ",finder)


# isalnum()

# txt = input("enter str")
# if txt.isalnum()== True:
#     print(txt)
# else:
#     print("ERR")               

# txt = input("enter word :") ar gamovida <><>
# count = int(input("enter num:"))
# import random
# gen = random.randint(0,10)
# print(gen)
# while count < gen:
#     if txt.isalnum():
#         print(txt)
#         count +=1

#         txt = input("enter a string")


# isalpha()

# txt = input("Enter a word to check: ")

# if txt.isalpha():
#     if not txt.capitalize() == txt:
#         txt = txt.capitalize()

#     # Print the modified string
#     print(txt)
# else:
#     print("Invalid input: Please enter an alphabetic word.")

# txt = input("enter ttetx:")
# if txt.isalpha():
#         print(txt.upper())


# isascii()

# txt = input("Enter text: ")
# count = 3

# if txt.isascii():
#     while count > 0:
#         print("Prog")
#         count -= 1
# else:
#     print("Input contains non-ASCII characters.")

# isdecimal()

# txt = input("Enter a number to check: ")

# if txt.isdecimal():
#     print(txt)
# else:
#     print("Input is not a valid decimal number.")

# txt = input("enter :")
# count = 0
# for i in txt:
#     if i.isdecimal():
#         count +=1
#         print(count)

# isdigit()
# while True:
#     txt = input("Enter a positive integer: ")
#     if txt.isdigit():
#         print("You entered:}"txt)
#         break
#     else:
#         print("Invalid input. Please enter a positive integer.")


# txt = input("enter smt")
# count = 0
# for i in txt:
#     if i.isdigit():
#         count +=1
#         print("Numbers of digit:",count)


# isidentifier()

# safe = ['if','Soko','yes']
# user = input("enter a word to check if its in the safe :")
# if user.isidentifier() and user in safe:
#     print("Yes its in safe")
# else:
#     print("no its not")    

# user = input("enter word:")
# if user.isidentifier() and not user.isdigit():
#     print("yes sirr")
# else:
#     print("no its not")    

# islower()

# txt = input("Enter a word: ")

# if not txt.islower():
#     txt = txt.lower()
#     print("Lowercase input:", txt)
# else:
#     print("Input is already lowercase:", txt)

# txt = input("Enter word:")
# if txt[0].capitalize and txt[1:].islower():
#     txt = txt.lower()
#     print(txt)

# isnumeric()

# user = input("enter to check if its numreci or not")
# count = 0
# for i in user:
#     if i.isnumeric():
#         count +=1
#     print("number of numeric character in string is ",count)

# safe = ['123','banana','234','skib']
# user = input("enter smt to see if its numeric or not:")
# num_word = [ word for word in safe if word.isnumeric()]
# print(num_word)

# isprintable()

# txt = input("enter :")
# c=0
# for smt in txt:
#     if smt.isprintable():
#         c+=1
#     print("Number of printable char:",c)    

# txt = input("enter string:")
# printC= " "
# for smt in txt:
#     if smt.isprintable():
#         printC +=smt
# print("printable:",printC)     



# isspace()

# while True:
#     txt = input("enter som:")
#     if not txt.isspace() and txt !="":
#          break
# print("enter smt to start conv")
# print("you entered",txt)


# istitle()


# sent = input("enter sentence")
# words = sent[0:len(sent)]
# title_count=0

# for word in words:
#     if word.istitle():
#         title_count+=1
# print("total number is",title_count)  




# isupper()


# txt = input("enter a string:")
# upLet = []

# for let in txt:
#     if let.isupper():
#         upLet.append(let)
# uperCount = len(upLet)
# print("total:",uperCount)        
# if upLet :
#     print (upLet)

# txt =input("enter a string:")
# for i in txt:
#  if i.isupper():
#         print(i)

# join()
# safe = []
# txt = input("enter:::")
# separate = input("enter separator")

# for word in txt:
#     if word.isupper():
#         safe.append(word)
#         if safe:
#             print(safe)
#             print(separate.join(safe))


# words =[]
# while True:
#     word = input("Enter a word (or press Enter to finish): ")
#     if word == "":
#         break
#     words.append(word)

# sentence =" ".join(words)
# print(sentence)        



# ljust()


# txt = input("enter smt")
# num = int(input("enter num to pad:"))
# smt = input("enter char")
# x = txt.ljust(num,smt)
# print(x)

# while True:
#     name = input("Enter name")

#     if not name:
#         break
#     phone = input("enter phone number:")
#     formatedN = name.ljust(20)
#     formatedP = phone.rjust(15)

#     print("formated Name:", formatedN)
#     print("formated Number:",formatedP)




# lower()

# txt = input("Enter text: ")

# if txt.isupper():  # Check if text is in uppercase
#     txt = txt.lower()  
#     print("Text is now lowered:", txt)
# else:
#     print("Text is not in uppercase:", txt)

# while True:
#     user = input("enter usernmae 3-15 char long")

#     if user.islower and 3< len(user) < 15:
#         print(user)
#         break
#     else:
#         print("invalid print again") 


# strip()

# user = input ("enter username").strip()
# if user == "":
#     print("username != empty")
# elif user != user.strip():
#         print("you can not do so")
# else:
#       print("finnaly",user)        

# pas = input("Enter password :").strip()
# print(pas)


# translate() and maketrans()


# vowel_to_number = str.maketrans('aeiou', '12345')

# text = input("Enter a string: ")

# trans_text = text.translate(vowel_to_number)

# print(text)
# print(trans_text)

# lower_to_upper_table = str.maketrans('abcdefghijklmnopqrstuvwxyz', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')

#  Get user input
# text = input("Enter a string: ")
# translated_text = text.translate(lower_to_upper_table)
# print(text)
# print(translated_text)

# patrition()

# txt = input("enter a string")
# finder = input("enter word to search for:")
# safe = []
# safe = txt.partition(finder)
# print("Before",safe[0])
# print("found",safe[1])
# print("after",safe[2])

# sentence = input("enter a sentcene")
# word = input("enter a word where to split")
# before,found,after = sentence.partition(word)
# if found:
#     print("before",before)
#     print("found",found)
#     print("after",after)
# else:
#     print("couldnt find it in sentence")

# email = input("enter email address:")
# user,simbol,domain = email.partition("@")

# if simbol:
#     print("user",user)
#     print("domain",domain)

# else:
#     print("Invalid email no @ found")    


# replace()

# fairytale = "Ertxel nikusha midioda maswavlebeltan, tumca nikushas pexi aucda da saxlshi gabrunda. dzahlma nikushas davaleba sjeuchama da achanta daumala"
# replacer1 = input("type words to replace specific area(nikusha)")
# replacer2 =input("type words to replace specific area(pexi)")

# modification =fairytale.replace("nikusha",replacer1)
# modification= modification.replace("pexi",replacer2)
# print(modification)

# import random
# story = "Ertxel nikusha midioda maswavlebeltan, tumca name pexi aucda da saxlshi gabrunda. dzahlma nikushas davaleba sjeuchama da achanta daumala"

# num =random.randint(0,3)
# print(num)

# if num == 0:
#     word = "Gio"
# elif num==1:
#     word="Nika"    
# elif num==2:
#     word="Mari"
# else:
#     word = "Mate"
# modification = story.replace("name",word)

# print("modified story:",modification)







# rfind()






# split()

# txt = input("Enter a sentence:")

# words = txt.split()

# for word in words:
#     print(word)


# email_addresses = input("Enter email addresses separated by spaces: ")
# emails = email_addresses.split()
# print("The domains are:")
# for email in emails:
#     username, domain = email.split('@')
#     print(domain)

# splitlines()

# text = input("Enter text use \\n:")

# lines = text.splitlines()
# count = len(lines)

# print("text contains",count,"lines")

# text = input("Enter a multi-line text (use \\n for new lines): ")

# lines = text.splitlines()
# print("Lines in reverse order:")
# for line in reversed(lines):
#     print(line)


# List of sentences




# sentences = [
#     "the quick brown fox jumps over the lazy dog",
#     "hello world",
#     "python is awesome",
#     "openai develops artificial intelligence",
#     "enjoy every moment",
#     "nospaceshere"
# ]

# Iterate over each sentence

 


# Define the football team dictionary
football_team = {}

def add_player():
    while True:
        # Input player number and check if it's already taken
        number = input("Enter player number (or type 'exit' to stop): ")
        if number.lower() == 'exit':
            break
        
        # Convert number to integer and check if it's valid
        if not number.isdigit() or int(number) <= 0:
            print("Invalid number. Please enter a positive integer.")
            continue
        
        number = int(number)
        
        if number in football_team:
            print(f"Number {number} is already taken. Please choose another number.")
            continue

        # Input player details
        name = input("Enter player name: ")
        position = input("Enter player position: ")
        market_value = input("Enter market value (in million €): ")

        # Check if market value is a valid float
        try:
            market_value = float(market_value)
        except ValueError:
            print("Invalid market value. Please enter a numeric value.")
            continue

        # Add player to the team
        football_team[number] = {
            "Name": name,
            "Position": position,
            "Market Value (€m)": market_value
        }

        print(f"Player {name} (Number {number}) added successfully!\n")

# Function to view the current team roster
def view_team():
    if not football_team:
        print("The team is currently empty.\n")


# Main program loop
while True:
    print("1. Add Player")
    print("2. View Team")
    print("3. Exit")
    
    choice = input("Choose an option: ")
    
    if choice == '1':
        add_player()
    elif choice == '2':
        view_team()
    elif choice == '3':
        print("Exiting the program. Goodbye!")
        break
    else:
        print("Invalid choice. Please choose a valid option.")
# 

