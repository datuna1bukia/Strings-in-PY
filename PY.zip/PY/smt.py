txt = "hello, and welcome to my world."

x = txt.capitalize()

print (x)
